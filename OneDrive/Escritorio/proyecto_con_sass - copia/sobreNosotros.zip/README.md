Se trabajo todo el sitio (los 5 html, el css y se agrego una 6ta pagina que funciona como Thank You page que no fue ilustrada en el wireframe. Se intento mantener la coherencia de diseño mas alla de eso)
Los formularios redirigen a la Thank you page ya que no hay base de datos.
Se utilizo @media, bootstrap, flex y grid.
Todo el sitio es responsive.
Se utilizo SCSS, partials, mixing, anidacion y variables
